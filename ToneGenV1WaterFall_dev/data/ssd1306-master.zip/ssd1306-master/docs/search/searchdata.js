var indexSectionsWithContent =
{
  0: "_abcdefghilmnoprstuvwxy",
  1: "_alnps",
  2: "acfilnoprstuv",
  3: "abcdefghilmnoprstuvwxy",
  4: "abcdfghilmnoprstwxy",
  5: "ilnst",
  6: "el",
  7: "bclvw",
  8: "agmrstu",
  9: "cdfhinost",
  10: "dhsu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "groups",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Modules",
  10: "Pages"
};

