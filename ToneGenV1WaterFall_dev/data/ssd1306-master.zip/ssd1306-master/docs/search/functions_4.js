var searchData=
[
  ['erase',['erase',['../struct_s_p_r_i_t_e.html#ab08b9b2831224d69a19d992819d100a2',1,'SPRITE']]],
  ['erasetrace',['eraseTrace',['../struct_s_p_r_i_t_e.html#ada52ad2a7aae3bdb62c6dc66ccb8765c',1,'SPRITE']]]
];
