var searchData=
[
  ['template_3a_20template_20control_20functions',['TEMPLATE: template control functions',['../group___t_e_m_p_l_a_t_e___o_l_e_d___a_p_i.html',1,'']]]
];
