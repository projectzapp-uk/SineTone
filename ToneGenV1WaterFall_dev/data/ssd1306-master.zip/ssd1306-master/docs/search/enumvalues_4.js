var searchData=
[
  ['white',['WHITE',['../canvas_8h.html#gadf764cbdea00d65edcd07bb9953ad2b7a283fc479650da98250635b9c3c0e7e50',1,'canvas.h']]]
];
